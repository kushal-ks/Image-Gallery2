import React, { Component } from 'react';
export class Collection extends Component{
  render(){
    return(
      <div>
        <h1>Collection</h1>          
      </div>
    )
  }
}