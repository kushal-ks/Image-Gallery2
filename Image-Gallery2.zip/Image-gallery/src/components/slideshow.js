import Reatc, { Component } from 'react';
import { Img } from ''
export class SlideShow extends Component {
  constructor() {
    super();
    this.state = {
      alldata: []
    }
  }

  componentWillMount() {
    var options = {
      "url": "https://api.unsplash.com/search/photos/random",
      "method": "GET",
      "headers": {
        "content-type": "application/json",
        "authorization": "Client-ID ba669894ff0f1edb0d720f2a8706c9589eb8b28eee5cd5b69154620e712ce691"
      }
    };
    var self = this;
    var data = [];
    request(options, function (err, res, body) {
      data = JSON.parse(body);
      this.setState({
        alldata: data.results,
      })
      debugger
    }.bind(this));


  }

  render() {
    return (
      <div>
        <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
          <div class="carousel-inner">
            <div class="carousel-item active">
              <Img src={this.state.alldata.urls.raw} />
            </div>
            <div class="carousel-item">
              <Img src={this.state.alldata.urls.raw} />
            </div>
            <div class="carousel-item">
              <Img src={this.state.alldata.urls.raw} />
            </div>
          </div>
      </div>


          </div>
          )
        }
      }
