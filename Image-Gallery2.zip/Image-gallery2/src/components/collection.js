import React, { Component } from 'react';
export class Collection extends Component{
  render(){
    debugger
    return(
      <div>
        <h1>Collection
          {this.props.some}</h1>          
      </div>
    )
  }
}