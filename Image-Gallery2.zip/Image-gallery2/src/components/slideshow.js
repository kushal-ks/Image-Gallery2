import React, { Component } from 'react';
import { Img } from '../components/img';
var request = require('request');
export class SlideShow extends Component {
  constructor() {
    super();
    this.state = {
      alldata: []
    }
  }

  _get_random_image(){
    alert("Random Image");
    var options = {
      "url": "https://api.unsplash.com/photos/random",
      "method": "GET",
      "headers": {
        "content-type": "application/json",
        "authorization": "Client-ID ba669894ff0f1edb0d720f2a8706c9589eb8b28eee5cd5b69154620e712ce691"
      }
    };
    var self = this;
    var data = [];
    request(options, function (err, res, body) {
      data = JSON.parse(body);
      this.setState({
        alldata: data,
      })
      debugger
    }.bind(this));
  }
  componentWillMount() {
   this._get_random_image();
  }

  render() {
    if (this.state.alldata.length == 0) {
      return ''
    }
    debugger
    return (
      
      <div className="container">

        <div class="card">
          <img class="d-block w-100" src={this.state.alldata.urls.raw} height={300} />
          <div class="card-img-overlay">
            <p class="card-text">
              <button  class="btn btn-primary" onClick={ this._get_random_image.bind(this)}>Please Click To Get Random Image</button>
            </p>
          </div>
        </div>
      </div>
    )
  }
}
